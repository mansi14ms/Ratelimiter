package customanno;

import customanno.Test;
import customanno.TesterInfo;
import customanno.TesterInfo.Priority;
import customanno.TesterInfo.Api;

@TesterInfo(
	priority = Priority.HIGH,
	api=Api.api1,
   rlimit= {100,200,300}
)
public class TestExample {

	@Test
	void testA() {
	  if (true)
		throw new RuntimeException("This test always failed");
	}

	@Test(enabled = false)
	void testB() {
	  if (false)
		throw new RuntimeException("This test always passed");
	}

	@Test(enabled = true)
	void testC() {
	  if (10 > 1) {
		// do nothing, this test always passed.
	  }
	}

}

