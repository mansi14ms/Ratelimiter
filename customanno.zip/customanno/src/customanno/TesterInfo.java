package customanno;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.TYPE) //on class level
public @interface TesterInfo {

	public enum Priority {
	   LOW, MEDIUM, HIGH
	}
	public enum Api {
		api1,api12,api3
	}
	
	

	Priority priority() default Priority.MEDIUM;
    Api api() default Api.api1;
    int[] rlimit() default 100;

	


}
