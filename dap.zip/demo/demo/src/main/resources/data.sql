INSERT INTO beer(name,abv) VALUES('Jai Alai', 7.5);
INSERT INTO beer(name,abv) VALUES('Stella Artois', 5.0);
INSERT INTO beer(name,abv) VALUES('Lagunitas IPA', 6.2);

COMMIT;

